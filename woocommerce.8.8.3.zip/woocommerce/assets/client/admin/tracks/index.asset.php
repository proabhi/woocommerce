<?php return array('dependencies' => array(), 'version' => '112baa6f1ca3405cae50');
