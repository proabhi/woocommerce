<?php return array('version' => '4b6545b5c50912e29640');
